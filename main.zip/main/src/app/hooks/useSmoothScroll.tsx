import React from 'react';

const useSmoothScroll = () => {
    return (
        <div>
            asdf
        </div>
    );
};

export default useSmoothScroll;