const UserInfoPage = () => {
  return (
    <div>
      <h1 className="text-4xl text-center mt-10">User Info</h1>
    </div>
  );
};

export default UserInfoPage;
